<?php

// Database Connection Information // 

define('DB_HOST' , 'localhost'); // INSERT HOSTNAME 

define('DB_NAME' , 'zfiles'); // INSERT DATABASE NAME 

define('DB_USER' , 'root'); // INSERT DATABASE USER 

define('DB_PASSWORD' , ''); // INSERT DATABASE PASSWORD 

// Optional Requirements  

define('CHARSET' , 'utf8'); // INSERT DATABASE CHARSET 

define('COLLATION' , 'utf8_unicode_ci'); // INSERT DATABASE COLLATION 

define('PREFIX' , ''); // INSERT DATABASE PREFIX 


?>