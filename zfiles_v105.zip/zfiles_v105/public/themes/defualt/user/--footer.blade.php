@if( $data['bottomAds'] )
<!-- bottom Advertising Area  -->
<div style="margin-top:20px;" class="col-md-11">
<div class="ads">
    {{ $data['bottomAds'] }}
</div>
</div>
<!-- /# bottom Advertising Area  -->
@endif
   

<!-- /# End page-content-wrapper -->
    </div>
    <!-- /#wrapper -->

</div>
