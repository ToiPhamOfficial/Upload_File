@if( $data['bottomAds'] )
<!-- bottom Advertising Area  -->
<div  class="col-md-12">
<div class="ads-bottom">
    {{ $data['bottomAds'] }}
</div>
</div>
<!-- /# bottom Advertising Area  -->
@endif
   

<!-- /# End page-content-wrapper -->
    </div>
    <!-- /#wrapper -->

</div>
