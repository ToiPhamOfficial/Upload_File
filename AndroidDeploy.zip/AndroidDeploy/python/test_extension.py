import json
from adb_service import ADBService

try:
    adb = ADBService()
    devices = adb.list_devices()

    result = {
        "success": True,
        "devices": devices
    }

except Exception as error:
    result = {
        "success": False,
        "error": str(error)
    }

print(json.dumps(result, ensure_ascii=False))