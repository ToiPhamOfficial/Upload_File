
from adb_service import ADBService, ADBError


def main():
    try:
        adb = ADBService()

        print("ADB: READY")
        print("\nDanh sách thiết bị:")

        devices = adb.list_devices()

        if not devices:
            print("Không tìm thấy thiết bị nào.")
            return

        for index, device in enumerate(devices, start=1):
            print(f"\n[{index}]")
            print(f"Serial: {device['serial']}")
            print(f"State: {device['state']}")
            print(f"Model: {device['model']}")

            if device["state"] == "device":
                info = adb.get_device_info(device["serial"])

                print(f"Manufacturer: {info['manufacturer']}")
                print(f"Android: {info['android_version']}")

    except ADBError as error:
        print(f"ADB ERROR: {error}")


if __name__ == "__main__":
    main()
