
import shutil
import subprocess


class ADBError(Exception):
    """Lỗi phát sinh khi giao tiếp với ADB."""
    pass


class ADBService:
    def __init__(self, adb_path=None, timeout=15):
        self.adb_path = adb_path or shutil.which("adb")
        self.timeout = timeout

        if not self.adb_path:
            raise ADBError(
                "Không tìm thấy adb. Hãy kiểm tra Android Platform Tools và PATH."
            )

    def _run(self, args, serial=None):
        """Thực thi một lệnh ADB."""

        command = [self.adb_path]

        if serial:
            command.extend(["-s", serial])

        command.extend(args)

        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout,
                check=False
            )

        except subprocess.TimeoutExpired:
            raise ADBError("ADB không phản hồi, đã hết thời gian chờ.")

        if result.returncode != 0:
            message = result.stderr.strip() or result.stdout.strip()
            raise ADBError(message or "ADB command failed.")

        return result.stdout.strip()

    def list_devices(self):
        """Lấy danh sách thiết bị đang được ADB nhận diện."""

        output = self._run(["devices", "-l"])
        devices = []

        for line in output.splitlines()[1:]:
            parts = line.split()

            if len(parts) < 2:
                continue

            serial = parts[0]
            state = parts[1]

            device = {
                "serial": serial,
                "state": state,
                "model": None,
                "product": None,
                "device": None
            }

            for item in parts[2:]:
                if ":" not in item:
                    continue

                key, value = item.split(":", 1)

                if key in device:
                    device[key] = value

            devices.append(device)

        return devices

    def get_device(self, serial):
        """Tìm thiết bị theo serial."""

        for device in self.list_devices():
            if device["serial"] == serial:
                return device

        return None

    def get_device_state(self, serial):
        """Lấy trạng thái kết nối của một thiết bị."""

        device = self.get_device(serial)

        if device is None:
            return "disconnected"

        return device["state"]

    def get_device_info(self, serial):
        """Lấy thông tin cơ bản của thiết bị đã kết nối."""

        state = self.get_device_state(serial)

        if state != "device":
            raise ADBError(
                f"Thiết bị chưa sẵn sàng. Trạng thái: {state}"
            )

        return {
            "serial": serial,
            "model": self._run(
                ["shell", "getprop", "ro.product.model"],
                serial
            ),
            "manufacturer": self._run(
                ["shell", "getprop", "ro.product.manufacturer"],
                serial
            ),
            "android_version": self._run(
                ["shell", "getprop", "ro.build.version.release"],
                serial
            )
        }
