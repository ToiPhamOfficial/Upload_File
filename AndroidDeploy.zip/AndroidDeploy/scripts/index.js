import { create } from '@bridge/sidebar'
import { Home } from '@bridge/ui'

create({
  id: 'android-deploy.main',
  displayName: 'Android Deploy',
  icon: 'mdi-android',
  component: Home,
})
