<template>
  <div style="padding: 16px;">
    <h2>Android Deploy</h2>

    <p>
      Minecraft Bedrock Add-on Deployment Tool
    </p>

    <v-divider class="my-4"></v-divider>

    <div>
      <p><strong>Extension Status:</strong></p>

      <p>{{ status }}</p>
    </div>

    <v-btn block color="primary" @click="testExtension">
      Test Extension
    </v-btn>

    <p style="margin-top: 16px; font-size: 12px;">
      Version 1.0.1
    </p>
    <v-divider class="my-4"></v-divider>

    <h3>Runtime Diagnostics</h3>

    <v-btn block color="secondary" @click="checkRuntime">
      Check Runtime
    </v-btn>

    <pre style="margin-top: 16px; white-space: pre-wrap;">{{ runtimeInfo }}</pre>
    <v-btn block color="success" @click="testBridgeTerminal">
      Test Bridge Terminal API
    </v-btn>
  </div>
</template>

<script>
export default {
  data() {
    return {
      status: 'Waiting for test...',
      runtimeInfo: 'Not checked'
    }
  },

  methods: {
    testExtension() {
      this.status = 'Extension is working!'
    },
    checkRuntime() {
      const g = typeof globalThis !== 'undefined'
        ? globalThis
        : window

      const processObject = g.process

      const info = {
        process: typeof g.process,
        require: typeof g.require,
        module: typeof g.module,

        nodeVersion: processObject?.versions?.node || null,
        electronVersion: processObject?.versions?.electron || null,
        platform: processObject?.platform || null
      }

      this.runtimeInfo = JSON.stringify(info, null, 2)
    },

    async testBridgeTerminal() {
    const tauri = window.__TAURI__;
    const unlisteners = [];

    const addLog = (message) => {
        this.runtimeInfo += '\n' + message;
    };

    try {
        this.runtimeInfo = '[INFO] Listening for Terminal output...';

        unlisteners.push(
            await tauri.event.listen('onStdoutMessage', (event) => {
                addLog('[STDOUT] ' + event.payload.message);
            })
        );

        unlisteners.push(
            await tauri.event.listen('onStderrMessage', (event) => {
                addLog('[STDERR] ' + event.payload.message);
            })
        );

        unlisteners.push(
            await tauri.event.listen('onCommandDone', () => {
                addLog('[DONE] Command finished');

                unlisteners.forEach(unlisten => unlisten());
            })
        );

        await tauri.tauri.invoke('execute_command', {
            cwd: '.',
            command: 'python -u extensions\\AndroidDeploy\\python\\test_extension.py'
        });

        addLog('[INFO] Command submitted');

    } catch (error) {
        addLog('[ERROR] ' + String(error));

        unlisteners.forEach(unlisten => unlisten());
    }
}

  }
}
</script>